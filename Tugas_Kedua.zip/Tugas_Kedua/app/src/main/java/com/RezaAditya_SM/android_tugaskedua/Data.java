package com.RezaAditya_SM.android_tugaskedua;

public class Data {
    public static int[] image = new int[]{
            R.drawable.kucing,
            R.drawable.bayi,
            R.drawable.buah,
            R.drawable.botol
    };

    public static String[] title = new String[]{
            "Contoh 1",
            "Contoh 2",
            "Contoh 3",
            "Contoh 4"
    };
    public static String[] description = new String[]{
            "Kucing Oren",
            "Bayi",
            "Buah",
            "Botol"
    };


}
